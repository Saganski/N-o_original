<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

$usuario = $_SESSION['usuario'];
$produtos = json_decode(file_get_contents("produtos.json"), true);

usort($produtos, fn($a, $b) => strtotime($a["data"]) - strtotime($b["data"]));

$nomes = [];
$produzidas = [];
$refugadas = [];
$taxa_producao = [];
$datas_formatadas = [];

foreach ($produtos as $produto) {
    $nomes[] = $produto["nome"];
    $produzidas[] = $produto["quantidade"];
    $refugadas[] = $produto["refugadas"];
    $tempo = $produto["tempo"] > 0 ? $produto["tempo"] : 1;
    $taxa_producao[] = round($produto["quantidade"] / $tempo, 2);
    $datas_formatadas[] = date("d/m", strtotime($produto["data"]));
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Área de Produtos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="content-language" content="pt-br">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      background-color: #0e0e0e;
      color: white;
      font-family: Arial, sans-serif;
      padding: 40px;
    }
    h1 {
      color: white;
      text-align: center;
      margin-bottom: 30px;
    }
    .chart-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 30px;
      max-width: 500px;
      margin: auto;
      padding: 40px 0;
    }
    canvas {
      background-color: #1a1a1a;
      border-radius: 20px;
      padding: 15px;
    }
    .filter-input {
      max-width: 400px;
      margin: 0 auto 20px auto;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <h1 class="navbar-brand">📦 Sistema de Produtos</h1>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="menuNavbar">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="cadastro.php">Cadastrar Produto</a></li>
        <li class="nav-item"><a class="nav-link" href="listagem.php">Listagem</a></li>
        <li class="nav-item"><a class="nav-link" href="calculos.php">Cálculos</a></li>
        <li class="nav-item"><a class="nav-link text-danger" href="sair.php">Sair</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4 text-center">
  <h2>Bem-vindo, <span class="text-primary"><?php echo htmlspecialchars($usuario); ?></span>!</h2>
</div>

<h1>📊 Gráficos de Produção e Refugo</h1>

<div class="filter-input text-center">
  <input type="text" id="filtro" class="form-control form-control-lg" placeholder="🔍 Filtrar por nome do produto">
</div>

<div class="chart-container">
  <canvas id="graficoBarra"></canvas>
  <canvas id="graficoPizza"></canvas>
  <canvas id="graficoLinha"></canvas>
</div>

<script>
const nomes = <?php echo json_encode($nomes); ?>;
const produzidas = <?php echo json_encode($produzidas); ?>;
const refugadas = <?php echo json_encode($refugadas); ?>;
const taxas = <?php echo json_encode($taxa_producao); ?>;
const datas = <?php echo json_encode($datas_formatadas); ?>;

const options = {
  responsive: true,
  animation: {
    duration: 1000,
    easing: 'easeOutQuart'
  },
  plugins: {
    legend: { labels: { color: 'white' } },
    title: { display: false }
  },
  scales: {
    x: { ticks: { color: 'white' } },
    y: { ticks: { color: 'white' } }
  }
};

// Gráficos
let barra, pizza, linha;

function criaGraficos(filtro = "") {
  const filtroMin = filtro.toLowerCase();
  const nomesFiltrados = [];
  const prodFiltradas = [];
  const refFiltradas = [];

  nomes.forEach((nome, i) => {
    if (nome.toLowerCase().includes(filtroMin)) {
      nomesFiltrados.push(nome);
      prodFiltradas.push(produzidas[i]);
      refFiltradas.push(refugadas[i]);
    }
  });

  if (barra) barra.destroy();
  if (pizza) pizza.destroy();

  barra = new Chart(document.getElementById("graficoBarra"), {
    type: "bar",
    data: {
      labels: nomesFiltrados,
      datasets: [
        {
          label: "Produzidas",
          data: prodFiltradas,
          backgroundColor: "#00ffcc"
        },
        {
          label: "Refugadas",
          data: refFiltradas,
          backgroundColor: "#ff4d6d"
        }
      ]
    },
    options
  });

  pizza = new Chart(document.getElementById("graficoPizza"), {
    type: "pie",
    data: {
      labels: nomesFiltrados.map((n, i) => `${n} (Refugo)`),
      datasets: [{
        data: refFiltradas,
        backgroundColor: nomesFiltrados.map(() => `hsl(${Math.random() * 360}, 100%, 50%)`)
      }]
    },
    options
  });
}

linha = new Chart(document.getElementById("graficoLinha"), {
  type: "line",
  data: {
    labels: datas,
    datasets: [{
      label: "Taxa de Produção (unid/min)",
      data: taxas,
      borderColor: "#00ffcc",
      backgroundColor: "#00ffcc33",
      fill: true,
      tension: 0.4
    }]
  },
  options
});

// Filtro ao digitar
document.getElementById("filtro").addEventListener("input", e => {
  criaGraficos(e.target.value);
});

// Inicial
criaGraficos();
</script>

</body>
</html>